package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.BlogHomePage;
import pages.BlogPostPage;

public class BlogHomeTests extends BaseTest {

    @Test
    public void testHomePageLoads() {
        BlogHomePage home = new BlogHomePage(driver);
        home.open();
        Assert.assertTrue(home.getPageTitle().contains("Blog"));
    }

    @Test
    public void testBlogHasPosts() {
        BlogHomePage home = new BlogHomePage(driver);
        home.open();
        Assert.assertTrue(home.getPostCount() > 0);
    }

    @Test
    public void testOpenFirstBlogPost() {
        BlogHomePage home = new BlogHomePage(driver);
        home.open();
        home.clickFirstPost();

        BlogPostPage post = new BlogPostPage(driver);
        Assert.assertTrue(post.getPostTitleText().length() > 0);
        Assert.assertTrue(post.contentIsVisible());
        Assert.assertTrue(post.getImageCount() >= 0);
    }

    @Test
    public void testPaginationPage2() {
        driver.get("https://practicetestautomation.com/blog/page/2/");
        Assert.assertTrue(driver.getCurrentUrl().contains("/page/2/"));
    }

    @Test
    public void testAllPostLinksAreValid() {
        BlogHomePage home = new BlogHomePage(driver);
        home.open();

        for (WebElement post : home.postItems) {
            WebElement link = post.findElement(By.cssSelector("a.entry-title-link"));
            Assert.assertTrue(link.getAttribute("href").startsWith("https://"));
        }
    }

    @Test
    public void testCanonicalLinkExists() {
        BlogHomePage home = new BlogHomePage(driver);
        home.open();
        Assert.assertTrue(home.getCanonicalHref().contains("/blog/"));
    }

    @Test
    public void testNextPageLinkExists() {
        BlogHomePage home = new BlogHomePage(driver);
        home.open();
        Assert.assertTrue(home.getNextHref().contains("/page/2/"));
    }

    @Test
    public void testPostTitlesAreNotEmpty() {
        BlogHomePage home = new BlogHomePage(driver);
        home.open();

        for (WebElement post : home.postItems) {
            String title = post.findElement(By.cssSelector("a.entry-title-link")).getText();
            Assert.assertTrue(title.length() > 0);
        }
    }
}
