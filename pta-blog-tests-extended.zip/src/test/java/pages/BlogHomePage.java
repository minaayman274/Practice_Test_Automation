package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class BlogHomePage {

    WebDriver driver;

    @FindBy(css = "article.post")
    public List<WebElement> postItems;

    @FindBy(css = "article.post a.entry-title-link")
    public WebElement firstPostLink;

    @FindBy(css = "link[rel='canonical']")
    public WebElement canonicalLink;

    @FindBy(css = "link[rel='next']")
    public WebElement nextPageLink;

    public BlogHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void open() {
        driver.get("https://practicetestautomation.com/blog/");
    }

    public int getPostCount() {
        return postItems.size();
    }

    public void clickFirstPost() {
        firstPostLink.click();
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    public String getCanonicalHref() {
        return canonicalLink.getAttribute("href");
    }

    public String getNextHref() {
        return nextPageLink.getAttribute("href");
    }
}
