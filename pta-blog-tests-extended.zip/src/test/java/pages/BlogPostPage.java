package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BlogPostPage {

    WebDriver driver;

    @FindBy(css = "h1.entry-title")
    public WebElement postTitle;

    @FindBy(css = "div.entry-content")
    public WebElement postContent;

    @FindBy(css = "img")
    public java.util.List<WebElement> images;

    public BlogPostPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public String getPostTitleText() {
        return postTitle.getText();
    }

    public boolean contentIsVisible() {
        return postContent.isDisplayed();
    }

    public int getImageCount() {
        return images.size();
    }
}
