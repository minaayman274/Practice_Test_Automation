package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ExceptionsPage {

    private WebDriver driver;

    public ExceptionsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void open() {
        driver.get("https://practicetestautomation.com/practice-test-exceptions/");
    }

    public boolean triggerNoSuchElement() {
        try {
            driver.findElement(By.id("NO-SUCH-ELEMENT"));
            return false;
        } catch (Exception e) {
            return true;
        }
    }
}
