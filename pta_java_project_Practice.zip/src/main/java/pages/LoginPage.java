package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    private WebDriver driver;

    private By username = By.id("username");
    private By password = By.id("password");
    private By submit = By.id("submit");
    private By message = By.id("message");
    private By logoutBtn = By.linkText("Log out");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void open() {
        driver.get("https://practicetestautomation.com/practice-test-login/");
    }

    public void login(String user, String pass) {
        driver.findElement(username).clear();
        driver.findElement(username).sendKeys(user);
        driver.findElement(password).clear();
        driver.findElement(password).sendKeys(pass);
        driver.findElement(submit).click();
    }

    public String getMessage() {
        return driver.findElement(message).getText();
    }

    public boolean isLoggedIn() {
        return driver.findElements(logoutBtn).size() > 0;
    }
}
