package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TablePage {

    private WebDriver driver;

    public TablePage(WebDriver driver) {
        this.driver = driver;
    }

    public void open() {
        driver.get("https://practicetestautomation.com/practice-test-table/");
    }

    public String getCell(int row, int col) {
        String xpath = String.format("//table//tbody/tr[%d]/td[%d]", row, col);
        return driver.findElement(By.xpath(xpath)).getText();
    }

    public int findRow(String text) {
        var rows = driver.findElements(By.xpath("//table//tbody/tr"));
        for (int i = 0; i < rows.size(); i++) {
            if (rows.get(i).getText().contains(text)) {
                return i + 1;
            }
        }
        return -1;
    }
}
