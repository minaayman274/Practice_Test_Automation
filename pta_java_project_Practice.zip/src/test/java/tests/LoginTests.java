package tests;

import base.BaseTest;
import pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest {

    @Test
    public void testValidLogin() {
        LoginPage page = new LoginPage(driver);
        page.open();
        page.login("student", "Password123");
        Assert.assertTrue(page.isLoggedIn(), "User should be logged in");
    }

    @Test
    public void testInvalidUsername() {
        LoginPage page = new LoginPage(driver);
        page.open();
        page.login("wrong", "Password123");
        Assert.assertTrue(page.getMessage().contains("invalid"));
    }

    @Test
    public void testInvalidPassword() {
        LoginPage page = new LoginPage(driver);
        page.open();
        page.login("student", "wrong");
        Assert.assertTrue(page.getMessage().contains("invalid"));
    }
}
