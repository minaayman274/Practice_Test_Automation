package tests;

import base.BaseTest;
import pages.ExceptionsPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ExceptionsTests extends BaseTest {

    @Test
    public void testNoSuchElement() {
        ExceptionsPage page = new ExceptionsPage(driver);
        page.open();
        Assert.assertTrue(page.triggerNoSuchElement());
    }
}
