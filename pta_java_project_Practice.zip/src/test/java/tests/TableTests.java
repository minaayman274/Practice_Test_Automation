package tests;

import base.BaseTest;
import pages.TablePage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TableTests extends BaseTest {

    @Test
    public void testTableRead() {
        TablePage page = new TablePage(driver);
        page.open();
        String cell = page.getCell(1, 1);
        Assert.assertFalse(cell.isEmpty());
    }

    @Test
    public void testFindRow() {
        TablePage page = new TablePage(driver);
        page.open();
        int row = page.findRow("JS");
        Assert.assertTrue(row > 0);
    }
}
