from selenium.webdriver.common.by import By

BASE = 'https://practicetestautomation.com/courses/'

def test_course_description(driver):
    driver.get(BASE)
    # Look for description paragraphs near course entries
    # Strategy: find article elements and then look for p tags inside
    articles = driver.find_elements(By.CSS_SELECTOR, 'article, .et_pb_post, .post')
    assert len(articles) > 0, 'No article/post elements found for course descriptions'
    # check first few articles for a paragraph/description
    found = False
    for art in articles[:5]:
        try:
            p = art.find_element(By.TAG_NAME, 'p')
            if p.text.strip():
                found = True
                break
        except Exception:
            continue
    assert found, 'No non-empty description paragraph found within first articles'
