from selenium.webdriver.common.by import By

BASE = 'https://practicetestautomation.com/courses/'

def test_page_load(driver):
    driver.get(BASE)
    # basic smoke: title should contain 'Courses' or site name
    title = driver.title.lower()
    assert 'course' in title or 'practice' in title or len(title) > 0
    # ensure main content has at least one article/course element
    # try common selectors with fallbacks
    articles = driver.find_elements(By.CSS_SELECTOR, 'article, .course, .et_pb_post')
    assert len(articles) > 0, "No article/course elements found on the courses page"
