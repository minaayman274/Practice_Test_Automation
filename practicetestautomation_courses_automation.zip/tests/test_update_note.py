from selenium.webdriver.common.by import By

BASE = 'https://practicetestautomation.com/courses/'

def test_update_note(driver):
    driver.get(BASE)
    # The test case mentioned: 'Find “My top-rated, best-selling course – f...“'
    # We'll search for a visible note/snippet that matches partial expected text.
    expected_snippet = 'top-rated'
    body_text = driver.find_element(By.TAG_NAME, 'body').text.lower()
    assert expected_snippet in body_text or 'best-selling' in body_text or 'top rated' in body_text, (
        'Expected update note snippet not found in page body text. You may need to update the expected text to match the site.'
    )
