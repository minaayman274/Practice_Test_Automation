from selenium.webdriver.common.by import By

BASE = 'https://practicetestautomation.com/courses/'

def test_navigation_links(driver):
    driver.get(BASE)
    # Try to find navigation bar links (header nav or breadcrumb)
    nav_selectors = ['nav a', '.main-navigation a', '.nav a', 'header a', '.menu a']
    links = []
    for sel in nav_selectors:
        elems = driver.find_elements(By.CSS_SELECTOR, sel)
        if elems:
            links = elems
            break
    assert len(links) > 0, 'No navigation links found using fallback selectors'

    # Check that at least one link points to a courses-related page or home (has href)
    hrefs = [a.get_attribute('href') for a in links if a.get_attribute('href')]
    assert any(h and ('course' in h or 'practicetestautomation.com' in h or '/' in h) for h in hrefs)
