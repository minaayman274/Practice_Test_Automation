from selenium.webdriver.common.by import By

BASE = 'https://practicetestautomation.com/courses/'

def test_course_title_display(driver):
    driver.get(BASE)
    # Look for course titles: common tag patterns h2, h3, .entry-title, .course-title
    selectors = ['.course-title', '.entry-title', 'h2', 'h3', '.et_pb_post .entry-title']
    titles = []
    for sel in selectors:
        elems = driver.find_elements(By.CSS_SELECTOR, sel)
        if elems:
            titles = elems
            break
    assert len(titles) > 0, 'No course title elements found'
    # Ensure at least one title has non-empty text
    visible_titles = [t.text.strip() for t in titles if t.text.strip()]
    assert len(visible_titles) > 0, 'Course titles found but text is empty'
