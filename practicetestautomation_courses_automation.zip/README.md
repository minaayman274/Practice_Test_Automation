# PracticeTestAutomation - Courses Page Automation (Selenium + pytest)

This project contains an example Selenium + pytest test suite targeting:
https://practicetestautomation.com/courses/

**Included tests (mapped to your test cases)**
- TC001 Page Load Test -> tests/test_page_load.py
- TC002 Navigation Links Test -> tests/test_navigation_links.py
- TC003 Course Title Display Test -> tests/test_course_title.py
- TC004 Course Description Test -> tests/test_course_description.py
- TC005 Update Note Test -> tests/test_update_note.py

**Notes**
- The assistant couldn't fetch the live page due to a 406 response when attempting to read the site HTML, so tests use flexible locator strategies and graceful fallbacks.
- You may need to adjust selectors if the site's DOM differs from the fallbacks provided.
- Uses Chrome in headless mode via webdriver-manager.

**How to run**
1. Create and activate a virtualenv.
2. Install requirements: `pip install -r requirements.txt`
3. Run tests: `pytest -q`

**Adjusting selectors**
If a test fails because of a selector mismatch, open the page in your browser, inspect the element, then edit the corresponding test in `tests/` to match the site's structure.

